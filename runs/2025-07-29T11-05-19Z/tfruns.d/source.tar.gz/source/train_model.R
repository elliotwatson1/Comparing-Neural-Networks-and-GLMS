library(keras)
library(tfruns)
library(dplyr)

# Define hyperparameters as flags
FLAGS <- flags(
  flag_integer("units1", 64),
  flag_integer("units2", 32),
  flag_numeric("dropout1", 0.3),
  flag_numeric("lr", 0.001),
  flag_integer("batch_size", 256)
)

# ---------------------------
library(insuranceData)

data(dataOhlsson)
data = dataOhlsson

str(data)
summary(data)
head(data)

data <- data[data$skadkost > 0 & data$duration > 0, ]

# Data split
set.seed(123) # for reproducibility
train_index <- createDataPartition(data$skadkost, p = 0.8, list = FALSE) # 80:20 split
train_data <- data[train_index, ]
test_data <- data[-train_index, ]
# ---------------------------

# Select same variables
vars <- c("skadkost", "agarald", "kon", "zon", "mcklass", "fordald", "bonuskl")

train_model <- train_data %>% select(all_of(vars))
test_model <- test_data %>% select(all_of(vars))

# Create design matrices
train_model <- model.matrix(skadkost ~ . -1, train_model) %>% as.data.frame()
train_model$skadkost <- train_data$skadkost

test_model <- model.matrix(skadkost ~ . -1, test_model) %>% as.data.frame()
test_model$skadkost <- test_data$skadkost

# Add log(duration)
train_model$log_duration <- log(train_data$duration)
test_model$log_duration <- log(test_data$duration)

normalise_train <- function(x) (x - min(x)) / (max(x) - min(x))

# Normalise training data
train_features <- train_model %>% select(-skadkost) %>% mutate_all(normalise_train)

# Capture min/max for each variable
mins <- sapply(train_model %>% select(-skadkost), min)
maxs <- sapply(train_model %>% select(-skadkost), max)

# Apply same scaling to test set
normalise_test <- function(x, varname) (x - mins[varname]) / (maxs[varname] - mins[varname])
test_features <- test_model %>%
  select(-skadkost) %>%
  mutate(across(everything(), ~ normalise_test(.x, cur_column())))

x_train <- as.matrix(train_features)
y_train <- log(train_model$skadkost)

x_test <- as.matrix(test_features)
y_test <- log(test_model$skadkost)

print(dim(x_train))
print(dim(y_train))
print(anyNA(x_train))
print(anyNA(y_train))
print(dim(x_test))
print(dim(y_test))
print(anyNA(x_test))
print(anyNA(y_test))

ncol(x_train)

x_train <- np_array(x_train)
y_train <- np_array(y_train)

x_test <- np_array(x_test)
y_test <- np_array(y_test)


# ---------------------------
# MODEL BUILDING
# ---------------------------
model <- keras_model_sequential()
model$add(layer_dense(units = FLAGS$units1, activation = "relu", input_shape = c(ncol(x_train))))
model$add(layer_dropout(rate = FLAGS$dropout1))
model$add(layer_dense(units = FLAGS$units2, activation = "relu"))
model$add(layer_dense(units = 1))

model$compile(
  loss = "mse",
  optimizer = optimizer_adam(learning_rate = FLAGS$lr),
  metrics = list("mean_squared_error", "mean_absolute_error")
)

# ---------------------------
# MODEL TRAINING
# ---------------------------
history <- model$fit(
  x = x_train,
  y = y_train,
  epochs = 100,
  batch_size = FLAGS$batch_size,
  validation_split = 0.2,
  callbacks = list(
    callback_early_stopping(patience = 10, restore_best_weights = TRUE)
  ),
  verbose = 0
)

# ---------------------------
# EVALUATE ON TRAINING SET (or on validation/test if you want)
# ---------------------------
scores <- model$evaluate(x_train, y_train, verbose = 0)

# Predict on training data to get MAE, RMSE explicitly
preds <- model$predict(x_train)

mae <- mean(abs(preds - y_train))
rmse <- sqrt(mean((preds - y_train)^2))

cat("MAE:", mae, "\n")
cat("RMSE:", rmse, "\n")

# ---------------------------
# SAVE METRICS FOR TFRUNS
# ---------------------------
write.csv(data.frame(mae = mae, rmse = rmse), file = "metrics.csv", row.names = FALSE)
