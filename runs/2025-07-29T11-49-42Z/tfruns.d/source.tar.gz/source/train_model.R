library(keras)
library(tfruns)
library(dplyr)

# Define hyperparameters as flags
FLAGS <- flags(
  flag_integer("units1", 64),
  flag_integer("units2", 32),
  flag_numeric("dropout1", 0.3),
  flag_numeric("lr", 0.001),
  flag_integer("batch_size", 256)
)

# ---------------------------


# ---------------------------
# MODEL BUILDING
# ---------------------------
model <- keras_model_sequential()
model$add(layer_dense(units = FLAGS$units1, activation = "relu", input_shape = c(ncol(x_train))))
model$add(layer_dropout(rate = FLAGS$dropout1))
model$add(layer_dense(units = FLAGS$units2, activation = "relu"))
model$add(layer_dense(units = 1))

model$compile(
  loss = "mse",
  optimizer = optimizer_adam(learning_rate = FLAGS$lr),
  metrics = list("mean_squared_error", "mean_absolute_error")
)

# ---------------------------
# MODEL TRAINING
# ---------------------------
history <- model$fit(
  x = x_train,
  y = y_train,
  epochs = as.integer(100),
  batch_size = FLAGS$batch_size,
  validation_split = 0.2,
  callbacks = list(
    callback_early_stopping(patience = 10, restore_best_weights = TRUE)
  ),
  verbose = 0
)

# ---------------------------
# EVALUATE ON TRAINING SET (or on validation/test if you want)
# ---------------------------
# Evaluate on test set
model$evaluate(x_test, y_test, verbose = 0)

# Predict on log-scale, then back-transform
log_preds_test <- model$predict(x_test)
preds_test <- as.numeric(exp(log_preds_test))

# Back-transform actuals
actual_test <- test_model$skadkost

# Calculate performance metrics
mae <- mean(abs(preds_test - actual_test))
rmse <- sqrt(mean((preds_test - actual_test)^2))
mse <- mean((preds_test - actual_test)^2)

cat("MAE:", mae, "\n")
cat("RMSE:", rmse, "\n")
cat("MSE:", mse, "\n")

# Save results to CSV
results <- data.frame(
  units1 = FLAGS$units1,
  units2 = FLAGS$units2,
  dropout1 = FLAGS$dropout1,
  lr = FLAGS$lr,
  batch_size = FLAGS$batch_size,
  mae = mae,
  rmse = rmse,
  mse = mse
)

# ---------------------------
# SAVE METRICS FOR TFRUNS
# ---------------------------

# Append to CSV (create if doesn't exist)
metrics_file <- "metrics.csv"
if (!file.exists(metrics_file)) {
  write.csv(results, metrics_file, row.names = FALSE)
} else {
  write.table(results, metrics_file, sep = ",", row.names = FALSE, col.names = FALSE, append = TRUE)
}


