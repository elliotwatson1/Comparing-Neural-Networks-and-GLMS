library(keras)
library(tfruns)
library(dplyr)

# Define custom Gamma deviance loss
gamma_loss <- function(y_true, y_pred){
  K <- backend()
  y_true <- K$clip(y_true, K$epsilon(), K$cast_to_floatx(1e10))
  y_pred <- K$clip(y_pred, K$epsilon(), K$cast_to_floatx(1e10))
  loss <- 2 * ((y_true - y_pred) / y_pred - K$log(y_true / y_pred))
  K$mean(loss, axis = as.integer(-1))
}

FLAGS <- flags(
  flag_integer("units1", 64),
  flag_integer("units2", 32),
  flag_integer("units3", 16), # optional third layer
  flag_numeric("dropout1", 0.3),
  flag_string("activation", "relu"),
  flag_string("final_activation", "relu"),
  flag_string("optimizer", "adam"),
  flag_integer("num_layers", 2),
  flag_integer("batch_size", 256),
  flag_numeric("lr", 0.001)
)

# ---------------------------
# Build model dynamically
# ---------------------------
model <- keras_model_sequential()
model$add(layer_dense(units = FLAGS$units1, activation = FLAGS$activation, input_shape = c(ncol(x_train))))
model$add(layer_dropout(rate = FLAGS$dropout1))

if (FLAGS$num_layers >= 2) {
  model$add(layer_dense(units = FLAGS$units2, activation = FLAGS$activation))
}
if (FLAGS$num_layers == 3) {
  model$add(layer_dense(units = FLAGS$units3, activation = FLAGS$activation))
}

# Final output layer
model$add(layer_dense(units = 1, activation = FLAGS$final_activation))

# Select optimizer
opt <- switch(FLAGS$optimizer,
              "adam" = optimizer_adam(learning_rate = FLAGS$lr),
              "rmsprop" = optimizer_rmsprop(learning_rate = FLAGS$lr),
              "sgd" = optimizer_sgd(learning_rate = FLAGS$lr),
              stop("Unsupported optimizer"))

model$compile(
  loss = gamma_loss,
  optimizer = opt,
  metrics = list("mean_squared_error", "mean_absolute_error")
)


# Fix: Convert inputs/targets to correct shape
# Convert to float32
x_train <- np$array(x_train, dtype = "float32")
y_train <- np$array(y_train, dtype = "float32")

x_test <- np$array(x_test, dtype = "float32")
y_test <- np$array(y_test, dtype = "float32")

# ---------------------------
history <- model$fit(
  x = x_train,
  y = y_train,
  epochs = as.integer(300),
  batch_size = FLAGS$batch_size,
  validation_split = as.integer(0.2),
  callbacks = list(callback_early_stopping(patience = as.integer(10), restore_best_weights = TRUE)),
  verbose = 0
)

# ---------------------------
model$evaluate(x_test, y_test, verbose = 0)

raw_preds_test <- model$predict(x_test)

preds_test <- as.numeric(raw_preds_test)       

actual_test <- test_model$skadkost

mae <- mean(abs(preds_test - actual_test))
rmse <- sqrt(mean((preds_test - actual_test)^2))
mse <- mean((preds_test - actual_test)^2)

cat("MAE:", mae, "\n")
cat("RMSE:", rmse, "\n")
cat("MSE:", mse, "\n")

results <- data.frame(
  units1 = FLAGS$units1,
  units2 = FLAGS$units2,
  units3 = FLAGS$units3,
  num_layers = FLAGS$num_layers,
  dropout1 = FLAGS$dropout1,
  activation = FLAGS$activation,
  final_activation = FLAGS$final_activation,
  optimizer = FLAGS$optimizer,
  lr = FLAGS$lr,
  batch_size = FLAGS$batch_size,
  mae = mae,
  rmse = rmse,
  mse = mse
)

metrics_file <- "metrics_huge_run.csv"
if (!file.exists(metrics_file)) {
  write.csv(results, metrics_file, row.names = FALSE)
} else {
  write.table(results, metrics_file, sep = ",", row.names = FALSE, col.names = FALSE, append = TRUE)
}