# Step 1: Load libraries
library(insuranceData)
library(neuralnet)
library(fastDummies)  # For one-hot encoding
library(caret)        # For train-test split
library(fitdistrplus)
library(ggplot2)
library(tidyverse)
library(gridExtra)
library(GGally)
library(reshape2)
library(glm2)
library(forcats)
library(brglm2)
library(e1071)

####################################################################################################################
############################################# BEGINNING OF EDA SECTION #############################################
####################################################################################################################
# LOADING DATA AND INITIAL VIEWS

data(dataOhlsson)
data = dataOhlsson

str(data)
summary(data)
head(data)

# INITIAL INSIGHTS
# Count missing values
sapply(data, function(x) sum(is.na(x))) # No missing values

# Summary of variable types and example anomalies
summary(data)

# Average claim cost by zone (bar plot)
ggplot(data, aes(x = as.factor(zon), y = skadkost)) +
  stat_summary(fun = mean, geom = "bar", fill = "steelblue") +
  labs(title = "Average Claim Cost by Zone", x = "Zone", y = "Avg skadkost")



# CODE FOR UNIVARIATE ANALYSIS
# Univariate analysis
# Histogram of numeric variables
numeric_vars <- c("agarald", "fordald", "bonuskl", "duration", "antskad", "skadkost")

data %>%
  select(all_of(numeric_vars)) %>%
  gather(variable, value) %>%
  ggplot(aes(x = value)) +
  facet_wrap(~ variable, scales = "free", ncol = 3) +
  geom_histogram(bins = 30, fill = "skyblue", color = "white") +
  theme_minimal() +
  labs(title = "Histograms of Numeric Variables")

# Create side-by-side histograms
# par(mfrow = c(1, 2))  # Set up a 1x2 plotting grid

# Histogram for skadkost
# hist(dataOhlsson$skadkost, 
#     main = "Histogram of skadkost",
#     xlab = "skadkost",
#     col = "lightblue",
#     border = "black")

# Histogram for antskad
#hist(dataOhlsson$antskad, 
#     main = "Histogram of antskad",
#     xlab = "antskad",
#     col = "lightgreen",
#     border = "black")

# Reset the plotting layout
# par(mfrow = c(1, 1))

# Bar plots of categorical variables
data %>%
  select(kon, zon, mcklass) %>%
  gather(variable, value) %>%
  ggplot(aes(x = as.factor(value))) +
  facet_wrap(~ variable, scales = "free", ncol = 3) +
  geom_bar(fill = "salmon") +
  theme_minimal() +
  labs(title = "Bar Plots of Categorical Variables", x = "Category", y = "Count")

# CODE FOR BIVARIATE ANALYSIS
## Bivariate Analysis
# Correlation Matrix of Numeric Variables
data %>%
  select(all_of(numeric_vars)) %>%
  cor() %>%
  round(2) %>%
  reshape2::melt() %>%
  ggplot(aes(Var1, Var2, fill = value)) +
  geom_tile() +
  geom_text(aes(label = value), color = "white") +
  scale_fill_gradient2(midpoint = 0, low = "green", mid = "black", high = "orange", limits = c(-1, 1)) +
  theme_minimal() +
  labs(title = "Correlation Matrix of Numeric Variables")

# Claim Frequency and Cost by Gender, Zone, and MC Class (already in your code)

# Zero inflation check
zero_freq <- mean(data$antskad == 0)
zero_cost <- mean(data$skadkost == 0)
cat("Percentage of zero claim frequency:", round(100 * zero_freq, 2), "%\n")
cat("Percentage of zero claim cost:", round(100 * zero_cost, 2), "%\n")

# Claim rate by age group
data %>%
  mutate(age_group = cut(agarald, breaks = seq(0, 100, 10), right = FALSE)) %>%
  group_by(age_group) %>%
  summarise(mean_claims = mean(antskad)) %>%
  ggplot(aes(x = age_group, y = mean_claims)) +
  geom_col(fill = "steelblue") +
  theme_minimal() +
  labs(title = "Average Claim Count by Driver Age Group", x = "Age Group", y = "Mean Claims")


# 1. Average claim frequency and cost by Gender
p1_freq <- ggplot(data, aes(x = kon, y = antskad)) +
  stat_summary(fun = mean, geom = "bar", fill = "steelblue") +
  labs(title = "Average Claim Frequency by Gender", x = "Gender", y = "Mean Claims")

p1_cost <- ggplot(data, aes(x = kon, y = skadkost)) +
  stat_summary(fun = mean, geom = "bar", fill = "lightblue") +
  labs(title = "Average Claim Cost by Gender", x = "Gender", y = "Mean Cost")

grid_gender <- grid.arrange(p1_freq, p1_cost, ncol = 2)

# 2. Average claim frequency and cost by Zone
p2_freq <- ggplot(data, aes(x = factor(zon), y = antskad)) +
  stat_summary(fun = mean, geom = "bar", fill = "darkorange") +
  labs(title = "Average Claim Frequency by Zone", x = "Zone", y = "Mean Claims")

p2_cost <- ggplot(data, aes(x = factor(zon), y = skadkost)) +
  stat_summary(fun = mean, geom = "bar", fill = "moccasin") +
  labs(title = "Average Claim Cost by Zone", x = "Zone", y = "Mean Cost")

grid_zone <- grid.arrange(p2_freq, p2_cost, ncol = 2)

# 3. Average claim frequency and cost by Motorcycle Class
p3_freq <- ggplot(data, aes(x = factor(mcklass), y = antskad)) +
  stat_summary(fun = mean, geom = "bar", fill = "seagreen") +
  labs(title = "Average Claim Frequency by Motorcycle Class", x = "MC Class", y = "Mean Claims")

p3_cost <- ggplot(data, aes(x = factor(mcklass), y = skadkost)) +
  stat_summary(fun = mean, geom = "bar", fill = "mediumseagreen") +
  labs(title = "Average Claim Cost by Motorcycle Class", x = "MC Class", y = "Mean Cost")

grid_mcclass <- grid.arrange(p3_freq, p3_cost, ncol = 2)

zero_freq <- mean(data$antskad == 0)
zero_cost <- mean(data$skadkost == 0)

cat("Percentage of zero claim frequency:", round(100 * zero_freq, 2), "%\n")
cat("Percentage of zero claim cost:", round(100 * zero_cost, 2), "%\n")

# CODE FOR PCA
# PCA plot
numeric_data <- data[, c("agarald", "fordald", "bonuskl", "duration", "skadkost")]
pca_result <- prcomp(numeric_data, scale. = TRUE)
summary(pca_result)
biplot(pca_result, main = "PCA Biplot")

# CODE FOR MODEL FITTING
# Poisson fit for antskad
fit_pois <- fitdist(dataOhlsson$antskad, "pois")
summary(fit_pois)
plot(fit_pois)

# Gamma fit for skadkost > 0
skadkost_nonzero <- data$skadkost[data$skadkost > 0]
fit_gamma <- fitdist(skadkost_nonzero, "gamma")
summary(fit_gamma)
plot(fit_gamma)

## END OF EDA SECTION

# Some tests to see if the data is Gamma distributed
skewness(test_data$skadkost)
kurtosis(test_data$skadkost)

gofstat(fit_gamma, fitnames = "Gamma")


####################################################################################################################
################################# BEGINNING OF GLM SECTION #########################################################
####################################################################################################################

# Filter out zero claim costs and zero durations
data <- data[data$skadkost > 0 & data$duration > 0, ]

# Ensure categorical variables are factors
data$zon <- as.factor(data$zon)
data$kon <- as.factor(data$kon)
data$mcklass <- as.factor(data$mcklass)

# Check for non-finite values
sapply(data[, c("skadkost", "agarald", "fordald", "bonuskl", "kon", "zon", "mcklass", "duration")],
       function(x) any(!is.finite(x)))

# Data split
set.seed(123) # for reproducibility
train_index <- createDataPartition(data$skadkost, p = 0.8, list = FALSE) # 80:20 split
train_data <- data[train_index, ]
test_data <- data[-train_index, ]

# Verify duration in training data
summary(log(train_data$duration))
any(!is.finite(log(train_data$duration))) # Should be FALSE

# Get the design matrix
X <- model.matrix(
  ~ agarald + fordald + bonuskl + kon + zon + mcklass,
  data = train_data
)

summary(X)
ncol(X) # Should be 17 (intercept + predictors, including dummy variables)
any(!is.finite(X)) # Should be FALSE
qr(X)$rank == ncol(X) # Should be TRUE for full rank

# Fit a simple Gamma GLM with log link for starting values
simple_model <- glm(
  skadkost ~ 1,
  family = Gamma(link = "log"),
  data = train_data,
  offset = log(duration),
  control = glm.control(maxit = 100)
)

# Create starting values (intercept from simple model, zeros for others)
start_vals <- c(coef(simple_model), rep(0, ncol(X) - 1))

# Fit Gamma GLM with log link and offset
glm_gamma <- glm2(
  skadkost ~ agarald + fordald + bonuskl + kon + zon + mcklass,
  family = Gamma(link = "log"),
  offset = log(duration),
  data = train_data,
  start = start_vals,
  control = glm.control(maxit = 1000, epsilon = 1e-8)
)

# Summary of the model
summary(glm_gamma)

# Predict on test set
test_data$predicted <- predict(glm_gamma, newdata = test_data, type = "response")

# Evaluate performance on test set
mse <- mean((test_data$skadkost - test_data$predicted)^2)
rmse <- sqrt(mse)
mae <- mean(abs(test_data$skadkost - test_data$predicted))
cat("Test MSE:", round(mse, 4), "\n")
cat("Test RMSE:", round(rmse, 4), "\n")
cat("Test MAE:", round(mae, 4), "\n")

# Plot predicted vs actual on log scale
ggplot(test_data, aes(x = skadkost, y = predicted)) +
  geom_point(alpha = 0.3) +
  geom_abline(slope = 1, intercept = 0, color = "red") +
  scale_x_log10() + scale_y_log10() +
  labs(title = "Gamma GLM: Predicted vs Actual on Test Set (Log Scale)",
       x = "Actual Claim Cost", y = "Predicted Claim Cost") +
  theme_minimal()

# Deviance
glm_gamma$deviance

# Psuedo-R^2
psr2 = 1 - (glm_gamma$deviance / simple_model$deviance)
psr2

# Extract fitted values and deviance residuals
fitted_values <- fitted(glm_gamma)
deviance_resid <- residuals(glm_gamma, type = "deviance")

# Plot - Residual analysis
plot(fitted_values, deviance_resid, pch = 20, col = "#1E90FF",
     main = "Deviance Residuals vs Fitted Values",
     xlab = "Fitted Values", ylab = "Deviance Residuals")
abline(h = 0, col = "red", lty = 2)

# Plot - Standardised residuals
std_resid <- rstandard(glm_gamma)
plot(fitted_values, std_resid, pch = 20, col = "#1E90FF",
     main = "Standardized Residuals vs Fitted Values",
     xlab = "Fitted Values", ylab = "Standardized Residuals")
abline(h = 0, col = "red", lty = 2)

# Plot - leverage plot
leverage <- hatvalues(glm_gamma)
plot(leverage, pch = 20, col = "#1E90FF",
     main = "Leverage Values",
     ylab = "Leverage")
abline(h = 2 * mean(leverage), col = "red", lty = 2) # Rule of thumb threshold

# Plot - Cook's Distance
cooksd <- cooks.distance(glm_gamma)
plot(cooksd, pch = 20, col = "#1E90FF",
     main = "Cook’s Distance",
     ylab = "Cook’s Distance")
abline(h = 4/nrow(train_data), col = "red", lty = 2) # Threshold

# Check for over dispersion
pchisq(summary(glm_gamma)$deviance, df = df.residual(glm_gamma), lower.tail = FALSE)

# Influential points
influential <- which(cooksd > 4/nrow(train_data))
print(influential) # Indices of influential points

####################################################################################################################
############################################### END OF GLM SECTION #################################################
####################################################################################################################
####################################################################################################################
############################################ BEGGINING OF NN SECTION ###############################################
####################################################################################################################
library(insuranceData)

data(dataOhlsson)
data = dataOhlsson

str(data)
summary(data)
head(data)

data <- data[data$skadkost > 0 & data$duration > 0, ]

# Data split
set.seed(123) # for reproducibility
train_index <- createDataPartition(data$skadkost, p = 0.8, list = FALSE) # 80:20 split
train_data <- data[train_index, ]
test_data <- data[-train_index, ]

############### IGNORE - UNLESS RUNNING FROM COMPLETELY FRESH ##################
installed.packages("keras")
library(reticulate)
use_condaenv("r-tensorflow", required = TRUE)
library(keras)
library(tensorflow)

install_tensorflow()

py_install(c("pydot", "graphviz"))

tf$config$list_physical_devices()
################################################################################


# Select same variables
vars <- c("skadkost", "agarald", "kon", "zon", "mcklass", "fordald", "bonuskl")

train_model <- train_data %>% select(all_of(vars))
test_model <- test_data %>% select(all_of(vars))

# Create design matrices
train_model <- model.matrix(skadkost ~ . -1, train_model) %>% as.data.frame()
train_model$skadkost <- train_data$skadkost

test_model <- model.matrix(skadkost ~ . -1, test_model) %>% as.data.frame()
test_model$skadkost <- test_data$skadkost

# Add log(duration)
train_model$log_duration <- log(train_data$duration)
test_model$log_duration <- log(test_data$duration)

normalise_train <- function(x) (x - min(x)) / (max(x) - min(x))

# Normalise training data
train_features <- train_model %>% select(-skadkost) %>% mutate_all(normalise_train)

# Capture min/max for each variable
mins <- sapply(train_model %>% select(-skadkost), min)
maxs <- sapply(train_model %>% select(-skadkost), max)

# Apply same scaling to test set
normalise_test <- function(x, varname) (x - mins[varname]) / (maxs[varname] - mins[varname])
test_features <- test_model %>%
  select(-skadkost) %>%
  mutate(across(everything(), ~ normalise_test(.x, cur_column())))

x_train <- as.matrix(train_features)
y_train <- log(train_model$skadkost)

x_test <- as.matrix(test_features)
y_test <- log(test_model$skadkost)

print(dim(x_train))
print(dim(y_train))
print(anyNA(x_train))
print(anyNA(y_train))
print(dim(x_test))
print(dim(y_test))
print(anyNA(x_test))
print(anyNA(y_test))

ncol(x_train)

x_train <- np_array(x_train)
y_train <- np_array(y_train)

x_test <- np_array(x_test)
y_test <- np_array(y_test)


model <- keras_model_sequential() 
model$add(layer_dense(units = 64, activation = "relu", input_shape = c(ncol(x_train))))

model$add(layer_dropout(rate = 0.3))
model$add(layer_dense(units = 32, activation = "relu"))
model$add(layer_dropout(rate = 0.3))
model$add(layer_dense(units = 1))

model$compile(
  loss = "mse",
  optimizer = optimizer_adam(),
  metrics = list("mean_squared_error", "mean_absolute_error")
)

history <- model$fit(
  x = x_train,
  y = y_train,
  epochs = as.integer(100),
  batch_size = as.integer(256),
  validation_split = as.integer(0.2),
  callbacks = list(
    callback_early_stopping(patience = as.integer(10), restore_best_weights = TRUE)
  )
)


model$evaluate(x_test, y_test)

# Predict and back-transform
log_preds_test <- model$predict(x_test)
preds_test <- exp(log_preds_test)

# Back-transform target too for consistency
actual_test <- test_model$skadkost

# Performance metrics
mae <- mean(abs(preds_test - actual_test))
rmse <- sqrt(mean((preds_test - actual_test)^2))
mse <- mean((preds_test - actual_test)^2)

cat("MAE:", mae, "\n")
cat("RMSE:", rmse, "\n")
cat("MSE:", mse, "\n")

###### psuedo-R^2 ###### ###################### TESTING ##################################################
observed <- as.vector(test_model$skadkost)     # Actual skadkost on original scale
predicted <- as.vector(preds_test)             # Neural network predictions (already back-transformed)

ss_res <- sum((observed - predicted)^2)
ss_tot <- sum((observed - mean(observed))^2)
pseudo_r2 <- 1 - ss_res / ss_tot

print(ss_res)
print(ss_tot)
print(pseudo_r2)
##########################################################################################################

# Visualize
plot_df <- data.frame(
  Actual = actual_test,
  Predicted = preds_test
)

ggplot(plot_df, aes(x = Actual, y = Predicted)) +
  geom_point(alpha = 0.5) +
  geom_abline(colour = "red") +
  labs(title = "Actual vs Predicted", x = "Actual skadkost", y = "Predicted") +
  theme_minimal()

###################### TESTING ##################################################
gamma_deviance <- custom_metric("gamma_deviance", function(y_true, y_pred){
  K <- backend()
  y_true <- K$clip(y_true, K$epsilon(), NULL)
  y_pred <- K$clip(y_pred, K$epsilon(), NULL)
  2 * ((y_true - y_pred) / y_pred - K$log(y_true / y_pred))
})

print(gamma_deviance)

model$summary()


save_model_hdf5(model, "model.h5")
#################################################################################


################## ATTEMPTING TO TUNE ##########################################
# V1
model <- keras_model_sequential() 
model$add(layer_dense(units = 64, input_shape = c(ncol(x_train))))
model$add(layer_batch_normalization())
model$add(layer_activation(activation ="relu"))
model$add(layer_dropout(rate = 0.3))

model$add(layer_dense(units = 32))
model$add(layer_batch_normalization())
model$add(layer_activation(activation ="relu"))
model$add(layer_dropout(rate = 0.3))
model$add(layer_dense(units = 16))
model$add(layer_batch_normalization())
model$add(layer_activation(activation ="relu"))
model$add(layer_dropout(rate = 0.3))
model$add(layer_dense(units = 8))
model$add(layer_batch_normalization())
model$add(layer_activation(activation ="relu"))
model$add(layer_dropout(rate = 0.3))
model$add(layer_dense(units = 1))

model$compile(
  loss = "mse",
  optimizer = optimizer_adam(),
  metrics = list("mean_squared_error", "mean_absolute_error")
)

history <- model$fit(
  x = x_train,
  y = y_train,
  epochs = as.integer(100),
  batch_size = as.integer(256),
  validation_split = as.integer(0.2),
  callbacks = list(
    callback_early_stopping(patience = as.integer(10), restore_best_weights = TRUE)
  )
)


model$evaluate(x_test, y_test)

# Predict and back-transform
log_preds_test <- model$predict(x_test)
preds_test <- exp(log_preds_test)

# Back-transform target too for consistency
actual_test <- test_model$skadkost

# Performance metrics
mae <- mean(abs(preds_test - actual_test))
rmse <- sqrt(mean((preds_test - actual_test)^2))
mse <- mean((preds_test - actual_test)^2)

cat("MAE:", mae, "\n")
cat("RMSE:", rmse, "\n")
cat("MSE:", mse, "\n")

# Visualize
plot_df <- data.frame(
  Actual = actual_test,
  Predicted = preds_test
)

ggplot(plot_df, aes(x = Actual, y = Predicted)) +
  geom_point(alpha = 0.5) +
  geom_abline(colour = "red") +
  labs(title = "Actual vs Predicted", x = "Actual skadkost", y = "Predicted") +
  theme_minimal()

################################### UNDERFITTING ###################################
# V2

library(tfruns)
runs <- tuning_run("train_model.R", 
                   flags = list(
                     units1 = c(32, 64, 128),
                     units2 = c(16, 32, 64),
                     dropout1 = c(0.2, 0.3, 0.4),
                     lr = c(0.001, 0.0005),
                     batch_size = c(128, 256)
                   ))



